
/* DO NOT MODIFY THIS FILE */ 

/* This is the signature for the function 
 * that you need to implement. 
 */ 
long foo ( long a, long b ) ; 
